Employee payroll management

Objecive:
The main objective of this project is to manage the details of the Employees, Payments and Salary. It also manages all the information about the Employee, Payroll and Salary slips. The project is totally built at the administration end of things. Only the administrator is granted access. The purpose of project is to build an application that reduces the manual work.

Functionalities:
-> Provides search facilities such as searching for employees
-> Tracks all salaries and employee payments
-> Stores all information about the employees to a secure SQL database
-> It generates reports of all employees, payments and salary slips
-> Manages all information of employees
-> Manages all information of emploee salaries

Software/Tools used:
Front end: Java swings
Databass: MySQL
Design tools: NetBeans IDE
